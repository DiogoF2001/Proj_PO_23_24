package xxl.core.content.functions;

import xxl.core.Content;
import xxl.core.content.Literal;
import xxl.core.content.LiteralString;
import xxl.core.exception.ContentException;

public abstract class Function extends Content{
	
	private String _name;

	public Function(String name){
		_name = name;
	}

	protected abstract Literal compute() throws ContentException;

	public String asString()  throws ContentException{
		return compute().asString();
	}

	public int asInt()  throws ContentException{
		return compute().asInt();
	}

	protected String getFunction(){
		return _name;
	}

	public Literal value(){
		Literal res;
		try {
			res = compute();
		} catch (ContentException | NullPointerException e) {
			return new LiteralString("#VALUE");
		}
		return res;
	}
}
