package xxl.core.content.functions;

import xxl.core.content.Range;

public abstract class IntervalFunction extends Function {
	protected Range _range;

	public IntervalFunction(String name, Range range){
		super(name);
		_range = range;
	}

	public String toString(){
		return "" + value().toString() + "=" + getFunction() + "(" + _range.toString() + ")";
	}
}
