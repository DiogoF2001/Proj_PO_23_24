package xxl.core.content;

import xxl.core.Content;
import xxl.core.exception.ContentException;

public abstract class Literal extends Content{
	protected Literal value(){
		return this;
	}

	public String asString() throws ContentException{
		throw new ContentException("A operação asString() não é suportada.");
	}
	
	public int asInt()  throws ContentException{
        throw new ContentException("A operação asInt() não é suportada.");	
    }
}
