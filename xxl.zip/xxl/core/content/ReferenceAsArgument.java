package xxl.core.content;

import xxl.core.Spreadsheet;

public class ReferenceAsArgument extends Reference {
	
	public ReferenceAsArgument(int row, int column, Spreadsheet s){
		super(row, column, s);
	}

	@Override
	public String toString(){
		if(value() == null)
			return super.toString().substring(7);
		else
			return super.toString().substring(value().toString().length()+1);
	}
}
