package xxl.core.content;

import xxl.core.Content;

public class LiteralString extends Literal {
	private String _value;

	public LiteralString(String s){
		_value = s;
	}

	@Override
	public String asString(){
		return _value;
	}

	public String toString(){
		if(_value != "#VALUE")
			return "\'" + _value;
		else
			return _value;
	}

	public Content copyConcrete(){
		return new LiteralString(_value);
	}
}
