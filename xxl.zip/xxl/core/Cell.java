package xxl.core;

import xxl.core.content.Literal;
import xxl.core.exception.NoContentException;

public class Cell implements java.io.Serializable {
	
	// Atributes
	private int _row;
	private int _column;
	private Content _content;
	private boolean _noContent;

	public Cell(int row, int column){
		_row = row;
		_column = column;
		_noContent = true;
	}

	public void setContent(Content c){
		_content = c;
		if(c == null)
			_noContent = true;
		else
			_noContent = false;
	}

	public Literal value() throws NoContentException{
		if(_noContent)
			throw new NoContentException();
		else
			return _content.value();
	}

	public String toString(){
		if(!_noContent)
			return "" + _row + ";" + _column + "|" + _content.toString();
		else
			return "" + _row + ";" + _column + "|";
	}

	public int getRow(){
		return _row;
	}

	public int getColumn(){
		return _column;
	}

	Content getContent(){
		return _content;
	}

	public Content copy(){
		if(_noContent)
			return null;
		else
			return _content.copyContent();
	}
}
