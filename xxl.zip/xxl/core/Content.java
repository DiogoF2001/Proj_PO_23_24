package xxl.core;

import xxl.core.content.Literal;
import xxl.core.exception.ContentException;

public abstract class Content implements java.io.Serializable {

	public abstract String toString();
	protected abstract Literal value();
	public abstract Content copyConcrete();

	public String asString()  throws ContentException{
		return value().asString();
	}

	public int asInt()  throws ContentException{
		return value().asInt();
	}

	Content copyContent(){
		return this.copyConcrete();
	}
}
