package xxl.core.exception;

public class NoContentException extends Exception {

	public NoContentException(){
		super();
	}
	
}
