package xxl.app.edit;

import java.util.ArrayList;
import pt.tecnico.uilib.menus.Command;
import xxl.core.Spreadsheet;
import xxl.core.Cell;

/**
 * Show cut buffer command.
 */
class DoShowCutBuffer extends Command<Spreadsheet> {

  DoShowCutBuffer(Spreadsheet receiver) {
    super(Label.SHOW_CUT_BUFFER, receiver);
  }
  
  @Override
  protected final void execute() {
    ArrayList<Cell> cells = _receiver.getCutBuffer().getCells();
	if(cells != null){
		for(Cell c: cells)
			_display.addLine(c.toString());
		_display.display();
	}
  }
}
