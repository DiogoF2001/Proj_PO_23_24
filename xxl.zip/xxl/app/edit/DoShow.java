package xxl.app.edit;

import java.util.ArrayList;

import pt.tecnico.uilib.menus.Command;
import pt.tecnico.uilib.menus.CommandException;
import xxl.core.Spreadsheet;
import xxl.app.exception.InvalidCellRangeException;
import xxl.core.Parser;
import xxl.core.content.Range;
import xxl.core.exception.InvalidCoordinatesException;
import xxl.core.exception.InvalidRangeFormatException;
import xxl.core.Cell;

/**
 * Class for searching functions.
 */
class DoShow extends Command<Spreadsheet> {

  DoShow(Spreadsheet receiver) {
    super(Label.SHOW, receiver);
	addStringField("range", Message.address());
  }
  
  @Override
  protected final void execute() throws CommandException{
    String s = stringField("range");
	Range range;
	ArrayList<Cell> cells = null;
	try {
		range = (new Parser(_receiver)).createRange(s);
		cells = range.getCells();
	} catch (InvalidRangeFormatException | InvalidCoordinatesException ex){
		throw new InvalidCellRangeException(s);
	}

	for(Cell c: cells)
		_display.addLine(c.toString());
	_display.display();

  }
}
