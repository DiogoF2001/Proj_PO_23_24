package xxl.app.edit;

import pt.tecnico.uilib.menus.Command;
import pt.tecnico.uilib.menus.CommandException;
import xxl.app.exception.InvalidCellRangeException;
import xxl.app.exception.InvalidContentException;
import xxl.core.Parser;
import xxl.core.Spreadsheet;
import xxl.core.content.Range;
import xxl.core.exception.ContentException;
import xxl.core.exception.InvalidCoordinatesException;
import xxl.core.exception.InvalidRangeFormatException;

/**
 * Copy command.
 */
class DoCopy extends Command<Spreadsheet> {

  DoCopy(Spreadsheet receiver) {
    super(Label.COPY, receiver);
    addStringField("range", Message.address());
  }
  
  @Override
  protected final void execute() throws CommandException {
	Range range;
	Parser p = new Parser(_receiver);
	try {
		range = p.createRange(stringField("range"));
		_receiver.getCutBuffer().setCells(range.getCells());
	} catch (InvalidRangeFormatException | InvalidCoordinatesException ex){
		throw new InvalidCellRangeException(stringField("range"));
	} catch (ContentException e){
		throw new InvalidContentException(e.getMessage(), e);
	}
  }
}
