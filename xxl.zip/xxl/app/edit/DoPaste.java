package xxl.app.edit;

import java.util.ArrayList;
import pt.tecnico.uilib.menus.Command;
import pt.tecnico.uilib.menus.CommandException;
import xxl.app.exception.InvalidCellRangeException;
import xxl.core.Cell;
import xxl.core.Parser;
import xxl.core.Spreadsheet;
import xxl.core.exception.InvalidCoordinatesException;
import xxl.core.exception.InvalidRangeFormatException;


/**
 * Paste command.
 */
class DoPaste extends Command<Spreadsheet> {

  DoPaste(Spreadsheet receiver) {
    super(Label.PASTE, receiver);
    addStringField("range", Message.address());
  }
  
  //@Override
  protected final void execute() throws CommandException {
	int i, row, col;
	String s = stringField("range");
	ArrayList<Cell> cells = null;
	ArrayList<Cell> cutBuffer = _receiver.getCutBuffer().getCells();
    if(_receiver.getCutBuffer().getCells().isEmpty())
		return;
	try {
		cells = (new Parser(_receiver)).createRange(s).getCells();
	} catch (InvalidRangeFormatException | InvalidCoordinatesException ex){
		throw new InvalidCellRangeException(s);
	}
	if(cells.size() == 1){
		row = cells.get(0).getRow();
		col = cells.get(0).getColumn();
		//System.out.println("rows: " + _receiver.getRows());
		//System.out.println("cols: " + _receiver.getColumns());
		if(_receiver.getCutBuffer().isVertical()){
			//System.out.println("Is vertically set");
			for (i = 0; i < cutBuffer.size() && i + col <= _receiver.getColumns(); i++) {
				//System.out.println("Copied to: " + (row+i) + ";" + col + " -> " + cutBuffer.get(i).copy());
				_receiver.getCell(row-1, col+i-1).setContent(cutBuffer.get(i).copy());
			}
		}
		else{
			//System.out.println("Is horizontally set");
			for (i = 0; i < cutBuffer.size() && i + row <= _receiver.getRows(); i++) {
				//System.out.println("Copied to: " + row + ";" + (col+i) + " -> " + cutBuffer.get(i).copy());
				_receiver.getCell(row+i-1, col-1).setContent(cutBuffer.get(i).copy());
			}
		}
		return;
	}
	if(_receiver.getCutBuffer().getCells().size() != cells.size() && cells.size() != 1)
		return;
	for (i = 0; i < cells.size(); i++) {
		cells.get(i).setContent(cutBuffer.get(i).copy());
	}
  }
}
