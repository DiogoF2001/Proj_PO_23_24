package xxl.app.edit;

import java.util.ArrayList;

import pt.tecnico.uilib.menus.Command;
import pt.tecnico.uilib.menus.CommandException;
import xxl.app.exception.InvalidCellRangeException;
import xxl.core.Cell;
import xxl.core.Parser;
import xxl.core.Spreadsheet;
import xxl.core.content.Range;
import xxl.core.exception.InvalidCoordinatesException;
import xxl.core.exception.InvalidRangeFormatException;


/**
 * Delete command.
 */
class DoDelete extends Command<Spreadsheet> {

	DoDelete(Spreadsheet receiver) {
		super(Label.DELETE, receiver);
		addStringField("range", Message.address());
	}
  
  	@Override
  	protected final void execute() throws CommandException {
		Range range;
		ArrayList<Cell> cells = null;
		Parser p = new Parser(_receiver);
		try {
			range = p.createRange(stringField("range"));
			cells = range.getCells();
		} catch (InvalidRangeFormatException | InvalidCoordinatesException ex){
			throw new InvalidCellRangeException(ex.getMessage());
		}

		for(Cell c: cells)
			c.setContent(null);
  }
}
