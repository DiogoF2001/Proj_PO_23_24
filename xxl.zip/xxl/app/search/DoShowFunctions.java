package xxl.app.search;

import java.util.ArrayList;

import pt.tecnico.uilib.menus.Command;
import xxl.core.Cell;
import xxl.core.Spreadsheet;

/**
 * Command for searching function names.
 */
class DoShowFunctions extends Command<Spreadsheet> {

  DoShowFunctions(Spreadsheet receiver) {
    super(Label.SEARCH_FUNCTIONS, receiver);
    addStringField("name", Message.searchFunction());
  }

  @Override
  protected final void execute() {
    String name = stringField("name");
	int i, j;
	Cell c;
	ArrayList<Cell> l = new ArrayList<Cell>();
	for (i = 0; i < _receiver.getRows(); i++) {
		for(j = 0; j < _receiver.getColumns(); j++){
			c = _receiver.getCell(i, j);
			if(c.toString().contains("=" + name))
				l.add(c);
		}
	}
	for (Cell cell : l) {
		_display.addLine(cell.toString());
	}
	_display.display();
  }
}
