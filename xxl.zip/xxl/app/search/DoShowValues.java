package xxl.app.search;

import java.util.ArrayList;

import pt.tecnico.uilib.menus.Command;
import xxl.core.Cell;
import xxl.core.Spreadsheet;
import xxl.core.exception.NoContentException;

/**
 * Command for searching content values.
 */
class DoShowValues extends Command<Spreadsheet> {

  DoShowValues(Spreadsheet receiver) {
    super(Label.SEARCH_VALUES, receiver);
    addStringField("value", Message.searchValue());
  }
  
  @Override
  protected final void execute() {
    String value = stringField("value");
	int i, j;
	Cell c;
	ArrayList<Cell> l = new ArrayList<Cell>();
	for (i = 0; i < _receiver.getRows(); i++) {
		for(j = 0; j < _receiver.getColumns(); j++){
			try{
				c = _receiver.getCell(i, j);
				if(c.value().toString().equals(value))
					l.add(c);
			} catch(NoContentException e){
				/*Does nothing because it simply means this cell's content is empty*/
			}
		}
	}
	for (Cell cell : l) {
		_display.addLine(cell.toString());
	}
	_display.display();
  }
}
