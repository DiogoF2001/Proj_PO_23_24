package xxl.app.main;

import pt.tecnico.uilib.forms.Form;
import pt.tecnico.uilib.menus.Command;
import pt.tecnico.uilib.menus.CommandException;
import xxl.core.Calculator;

/**
 * Open a new file.
 */
class DoNew extends Command<Calculator> {

	DoNew(Calculator receiver) {
		super(Label.NEW, receiver);
	}

	//@Override
	protected final void execute() throws CommandException {
		Integer rows;
		Integer cols;
		String name;
		try {
			if(_receiver.getSpreadsheet() != null){
				if(_receiver.getSpreadsheet().hasChanged()){
					_display.clear();
					if(Form.confirm(Message.saveBeforeExit()))
					{
						if(_receiver.getFile() == null){
							name = Form.requestString(Message.newSaveAs());
							_receiver.saveAs(name);
						}
						else
							_receiver.saveAs(_receiver.getFile());
							
					}
				}
				
			}
			
		} catch(Exception e) {
			//throw new CommandException(e);
		}
		rows = Form.requestInteger(Message.lines());
		cols = Form.requestInteger(Message.columns());
		_receiver.createNewSpreadsheet(rows, cols);
	}
}

