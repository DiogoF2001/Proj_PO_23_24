package xxl.app.main;

import java.io.FileNotFoundException;
import java.io.IOException;

import pt.tecnico.uilib.forms.Form;
import pt.tecnico.uilib.menus.Command;
import pt.tecnico.uilib.menus.CommandException;
import xxl.core.Calculator;

/**
 * Save to file under current name (if unnamed, query for name).
 */
class DoSave extends Command<Calculator> {

  DoSave(Calculator receiver) {
    super(Label.SAVE, receiver, xxl -> xxl.getSpreadsheet() != null);
  }
  
  //@Override
  protected final void execute() throws CommandException{
    if(_receiver.getSpreadsheet().hasChanged()){
		if(_receiver.getFile() == null){
			_receiver.setFile(Form.requestString(Message.newSaveAs()));
		}
		try{
			_receiver.saveAs(_receiver.getFile());
		}
		/*catch(Exception ex){

		}*/
		catch(FileNotFoundException ex){
			System.out.println("FileNotFoundException");
		}
		catch(IOException e1){
			System.out.println(e1.getMessage() + " IOException for some reason...\n");
		}
		catch(Exception e){
			System.out.println("Another type of exception");
		}
	}
  }
}
