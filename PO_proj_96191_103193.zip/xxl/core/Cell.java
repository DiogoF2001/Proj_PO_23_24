package xxl.core;

import xxl.core.content.Literal;

public class Cell {
	
	// Atributes
	private int _row;
	private int _column;
	private Content _content;
	private boolean _noContent;

	public Cell(int row, int column){
		_row = row;
		_column = column;
		_noContent = true;
	}

	void setContent(Content c){
		_content = c;
		_noContent = false;
	}

	public Literal value(){
		return _content.value();
	}

	public String toString(){
		if(_noContent)
			return "" + _row + ";" + _column + "|" + _content.toString();
		else
			return "" + _row + ";" + _column + "|";
	}
}
