package xxl.core;

import java.util.ArrayList;

public class User {
	
	private String _name;
	private ArrayList<Spreadsheet> _activeSheets;

	public User(String n){
		_name = n;
		_activeSheets = new ArrayList<Spreadsheet>();
	}

	public String getName(){
		return _name;
	}

	public void addSheet(Spreadsheet s){
		_activeSheets.add(s);
	}

}
