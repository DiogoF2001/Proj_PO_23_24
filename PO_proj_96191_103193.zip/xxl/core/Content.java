package xxl.core;

import xxl.core.content.Literal;

public abstract class Content {

	public abstract String toString();
	protected abstract Literal value();

	public String asString(){
		return value().asString();
	}

	public int asInt(){
		return value().asInt();
	}
}
