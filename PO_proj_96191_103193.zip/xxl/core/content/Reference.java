package xxl.core.content;

import xxl.core.Content;
import xxl.core.Spreadsheet;

public class Reference extends Content{
	private int _row;
	private int _column;
	private Spreadsheet _sheet;

	public Reference(int row, int column, Spreadsheet s){
		_row = row;
		_column = column;
		_sheet = s;
	}

	protected Literal value(){
		return _sheet.getCell(_row, _column).value();
	}

	public String toString(){
		return "=" + _row + ";" + _column;
	}
}
