package xxl.core.content;

public class LiteralInteger extends Literal {
	private int _value;

	public LiteralInteger(int value){
		_value = value;
	}

	@Override
	public int asInt(){
		return _value;
	}

	public String toString(){
		return "" + _value;
	}
}
