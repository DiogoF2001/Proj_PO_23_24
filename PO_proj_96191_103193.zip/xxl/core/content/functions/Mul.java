package xxl.core.content.functions;

import xxl.core.Content;
import xxl.core.content.Literal;
import xxl.core.content.LiteralInteger;

public class Mul extends BinaryFunction {
	public Mul(Content arg1, Content arg2){
		super("MUL", arg1, arg2);
	}

	protected Literal compute(){
		LiteralInteger result = new LiteralInteger(_arg1.asInt() * _arg2.asInt());
		return result;
	}
}
