package xxl.core.content.functions;

import xxl.core.Content;
import xxl.core.content.Literal;

public abstract class Function extends Content{
	
	private String _name;

	public Function(String name){
		_name = name;
	}

	protected abstract Literal compute();

	public String asString(){
		return compute().asString();
	}

	public int asInt(){
		return compute().asInt();
	}

	protected String getFunction(){
		return _name;
	}

	public Literal value(){
		return compute();
	}
}
