package xxl.core.content;

import xxl.core.Content;

public abstract class Literal extends Content{
	protected Literal value(){
		return this;
	}

	public String asString(){
		throw new UnsupportedOperationException("A operação asString() não é suportada.");
	}
	
	public int asInt() {
        throw new UnsupportedOperationException("A operação asInt() não é suportada.");	
    }
}
