package xxl.core.content;

import xxl.core.Spreadsheet;

public class ReferenceAsArgument extends Reference {
	
	public ReferenceAsArgument(int row, int column, Spreadsheet s){
		super(row, column, s);
	}

	@Override
	public String toString(){
		return super.toString().substring(1);
	}
}
