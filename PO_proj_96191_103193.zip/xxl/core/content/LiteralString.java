package xxl.core.content;

public class LiteralString extends Literal {
	private String _value;

	public LiteralString(String s){
		_value = s;
	}

	@Override
	public String asString(){
		return _value;
	}

	public String toString(){
		return "'" + _value;
	}
}
