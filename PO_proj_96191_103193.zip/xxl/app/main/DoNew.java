package xxl.app.main;

import pt.tecnico.uilib.forms.Form;
import pt.tecnico.uilib.menus.Command;
import pt.tecnico.uilib.menus.CommandException;
import xxl.core.Calculator;

/**
 * Open a new file.
 */
class DoNew extends Command<Calculator> {

	DoNew(Calculator receiver) {
		super(Label.NEW, receiver);
	}

	//@Override
	protected final void execute() throws CommandException {
		/*try {
			// Limpar ou inicializar o estado da calculadora
			_receiver.clear();
			// Informar ao usuário que um novo arquivo foi criado (ou estado reiniciado)
			Form.showInformation(Label.NEW, Message.SUCCESS_NEW_FILE_CREATED);
		} catch(Exception e) {
			
			Form.showError(Label.NEW, Message.ERROR_CREATING_NEW_FILE);
			throw new CommandException(e);
		}*/
	}
}

