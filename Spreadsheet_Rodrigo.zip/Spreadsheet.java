package xxl.core;

// FIXME import classes

import java.io.Serial;
import java.io.Serializable;

import xxl.core.exception.UnrecognizedEntryException;

/**
 * Class representing a spreadsheet.
 */
public class Spreadsheet implements Serializable {
  	@Serial
  	private static final long serialVersionUID = 202308312359L;
  


  	// FIXME define attributes

	private int _rows;
	private int _columns;
	private Cell _cells[][];
	//  ??  private int _changed;



  	// FIXME define contructor(s)

	public Spreadsheet(int rows, int columns){
		int i, j;
		_rows = rows;
		_columns = columns;
		_cells = new Cell[rows][columns];
		for(i = 0; i < rows; i++){
			for (j = 0; j < columns; j++) {
				_cells[i][j] =  new Cell(i, j);
			}
		}
	}

	//save
	public static void saveToFile(Spreadsheet sheet, String filename) throws IOException {
    	try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(filename))) {
        	oos.writeObject(sheet);
    	}
	}

	//load
	public static Spreadsheet loadFromFile(String filename) throws IOException, ClassNotFoundException {
    	try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(filename))) {
        	return (Spreadsheet) ois.readObject();
    	}
	}

	// FIXME define methods
	
	/**
	 * Insert specified content in specified address.
	 *
	 * @param row the row of the cell to change 
	 * @param column the column of the cell to change
	 * @param contentSpecification the specification in a string format of the content to put
	 *        in the specified cell.
	 */
	public void insertContent(int row, int column, Content contentSpecification) throws UnrecognizedEntryException {
		getCell(row, column).setContent(contentSpecification);
	}

	public Cell getCell(int row, int column){
		return _cells[row][column];
	}

	public boolean checkCoords(int row, int column){
		return !(row < 1 || row >= _rows || column < 1 || column >=_columns);
	}
}
